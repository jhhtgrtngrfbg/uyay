./xmrig --url pool.hashvault.pro:80 --user 83Q5hyQXSWUbhSViAPUchZdTzx2GNF6F2URuHVSmpy2xcRHNWnDdu5iCQ8XK4PvcvxPx1vZYQL1NHUkhgzhtzJYU7mhrc8f --pass xayi --donate-level 1 --tls --tls-fingerprint 420c7850e09b7c0bdcf748a7da9eb3647daf8515718f36d9ccfdd6b9ff834b14 t 50

